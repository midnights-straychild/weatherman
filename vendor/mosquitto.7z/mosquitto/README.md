# 윈도우용으로 빌드한 mosquitto 바이너리
websocket을 지원하는 mosquitto 바이너리 파일

## 빌드 환경

* 빌드 툴:
Visual Studio 2015

* 빌드 방법
building_mosquitto_on_windows.pptx 파일 참고

* 실행을 위해 필요한 패키지
OpenSSL binary(Light Version)
